/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebot;

/**
 *
 * @author Condor
 */
public class DirectionDroite extends RebotState{
    
    public DirectionDroite(Rebot rebot) {
        super(rebot);
    }
    
    @Override
    public void haut()
    {
       
       rebot.setState(new DirectionHaut(rebot));   
    }
    @Override
    public void bas()
    {
       
        rebot.setState(new DirectionBas(rebot));
    }
    @Override
    public void gauche()
    {

        rebot.setState(new DirectionGauche(rebot));
    }
    
    
}
