/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebot;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;
import org.emp.gl.ienvironnement.IEnvironnement;
import org.emp.gl.irebot.IRebot;
import org.emp.gl.lookuppackage.Lookup;



/**
 *
 * @author Condor
 */
public class Rebot implements IRebot{
 
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    
    public int x=0;
    public int y=0;
    
    RebotState state = new DirectionInitiale(this);
    
    @Override
    public void haut()
    {
        state.haut();
    }
    
    @Override
    public void bas()
    {
        state.bas();
    }
    
    @Override
    public void gauche()
    {
        state.gauche();
    }
    
    @Override
    public void droite()
    {
        state.droite();
    }
    
    public void setState(RebotState state)
    {
        this.state=state;
    }
    
    

    @Override
    public void propertyChange(PropertyChangeEvent pce) {
        
          // chaque seconde 
        
        if(state.getClass()== DirectionHaut.class)
        {
            y++;
            chekYposition();
                   chekXmatriceEnveronnement();
            pcs.firePropertyChange("", x, null);
        }
        if(state.getClass()== DirectionBas.class)
        {
            y--;
            chekYposition();
            chekXmatriceEnveronnement();
            
            pcs.firePropertyChange("", null, x);
        }
        if(state.getClass()== DirectionDroite.class)
        {
            x++;
            chekXposition();
            chekXmatriceEnveronnement();
             
            pcs.firePropertyChange("", null, null);
        }
        if(state.getClass()== DirectionGauche.class)
        {
            x--;
            chekXposition();
            chekXmatriceEnveronnement();
             
            pcs.firePropertyChange("", null, x);
        }   
       
    }
    
    public void chekYposition()
    {
        if(y<0)
        {
            y=0;
        }
        if(y>10)
        {
            y=10;
        }
    }
    
    public void chekXposition()
    {
        if(x<0)
        {
           x=0; 
        }
        if(x>10)
        {
            x=10;
        }
    }
    
    public void chekXmatriceEnveronnement()
    {
        IEnvironnement environnement = Lookup.getInstance().getService(IEnvironnement.class);
        int [][] matriceEnvironnement = environnement.getMatriceEnveronnement();
        for(int parcoursX=0 ; parcoursX< 10 ; parcoursX ++)
        {
            for(int parcoursY=0 ; parcoursY< 10 ; parcoursY ++)
            {
                if(matriceEnvironnement[parcoursX][parcoursY] == 1 && x< parcoursX && y== parcoursY-1 )
                {
                    x = parcoursX-1;
                }
                if(matriceEnvironnement[parcoursX][parcoursY] == 1 && y> parcoursY && x== parcoursX+1)
                {
                    y = parcoursY-1;
                }
                if(matriceEnvironnement[parcoursX][parcoursY] == 1 && x> parcoursX && y== parcoursY+1)
                {
                    x = parcoursX+1;
                }
                if(matriceEnvironnement[parcoursX][parcoursY] == 1 && y< parcoursY && x== parcoursX-1)
                {
                    y = parcoursY-1;
                }
            }
        }
        
        
    }
    
    public void addTimeChangeListener(IEnvironnement ienvironnement) {
        pcs.addPropertyChangeListener(ienvironnement);
    }

    
    public void removeTimeChangeListener(IEnvironnement ienvironnement) {
       pcs.removePropertyChangeListener(ienvironnement);
    }
    
    @Override
    public List<Integer> getPosition()
    {
        List<Integer> list = new ArrayList<>();
        list.add(x);
        list.add(y);
        return list;
    }
  
    
}




