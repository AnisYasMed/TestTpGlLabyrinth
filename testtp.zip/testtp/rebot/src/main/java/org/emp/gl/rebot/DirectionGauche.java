/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebot;

/**
 *
 * @author Condor
 */
public class DirectionGauche extends RebotState{
    
    public DirectionGauche(Rebot rebot) {
        super(rebot);
    }
    
    @Override
    public void haut()
    {
        
       rebot.setState(new DirectionHaut(rebot));   
    }
    @Override
    public void droite()
    {
        
        rebot.setState(new DirectionDroite(rebot));
    }
    @Override
    public void bas()
    {
       
        rebot.setState(new DirectionBas(rebot));
    }
    
    
}
