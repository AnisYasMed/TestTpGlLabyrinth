/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.launcher;


import org.emp.gl.environnement.Environnement;
import org.emp.gl.ienvironnement.IEnvironnement;
import org.emp.gl.irebot.IRebot;
import org.emp.gl.lookuppackage.Lookup;
import org.emp.gl.rebot.Rebot;
import org.emp.gl.timerservice.TimerService;
import org.emp.gl.timerserviceimplwithdelegation.TimerServiceImplWithDelegation;

/**
 *
 * @author Condor
 */
public class Launcher {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rebot rebot = new Rebot();
        Lookup.getInstance().register(IRebot.class, rebot);
        
        TimerServiceImplWithDelegation timer = new TimerServiceImplWithDelegation();
        
        
        Lookup.getInstance().register(TimerService.class, new TimerServiceImplWithDelegation());
        timer.addTimeChangeListener(rebot);
        IEnvironnement environnement = new Environnement();
        Lookup.getInstance().register(IEnvironnement.class, environnement);
        
        rebot.addTimeChangeListener(environnement);
        
    }
    
}
