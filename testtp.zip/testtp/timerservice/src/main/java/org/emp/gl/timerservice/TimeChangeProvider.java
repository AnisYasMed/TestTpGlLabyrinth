
package org.emp.gl.timerservice;

import org.emp.gl.irebot.IRebot;

public interface TimeChangeProvider {

    public void addTimeChangeListener(IRebot irebot);

    public void removeTimeChangeListener(IRebot irebot);
}
