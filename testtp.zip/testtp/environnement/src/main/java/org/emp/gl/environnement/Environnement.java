/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.environnement;

import java.beans.PropertyChangeEvent;
import java.util.List;
import org.emp.gl.ienvironnement.IEnvironnement;
import org.emp.gl.irebot.IRebot;
import org.emp.gl.lookuppackage.Lookup;


/**
 *
 * @author Condor
 */
public class Environnement extends javax.swing.JFrame implements IEnvironnement {

   private final int[][] matriceEnvironnement = new int[10][10];
   
   public void initialisationMatrice()
   {
        for(int parcoursX=0 ; parcoursX< 10 ; parcoursX ++)
        {
            for(int parcoursY=0 ; parcoursY< 10 ; parcoursY ++)
            {
                matriceEnvironnement[parcoursX][parcoursY]=0;
            }
        }
        
   }
   
   
   public void caseObstacles()
   {
       // exemple sur les obstacles dans la matrice
       
       matriceEnvironnement[0][0]=1;
     
   }
   
   public void tableMatrice()
   {
       for(int parcoursX=0; parcoursX<10; parcoursX++)
       {
           for(int parcoursY=0; parcoursY<10; parcoursY++)
           {
               matrice.setValueAt(matriceEnvironnement[parcoursX][parcoursY], parcoursX, parcoursY);
           }
       }
   }
   
   @Override
   public int[][] getMatriceEnveronnement()
   {
       return matriceEnvironnement;
   }
   
   public Environnement() {
        initComponents();
        setVisible(true);
        caseObstacles();
        tableMatrice();
      
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        haut = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        gauche = new javax.swing.JButton();
        droite = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        matrice = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new java.awt.GridLayout(1, 0));

        haut.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        haut.setText("HAUT");
        haut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hautActionPerformed(evt);
            }
        });
        jPanel1.add(haut);

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton2.setText("BAS");
        jButton2.setActionCommand("");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);

        gauche.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        gauche.setText("GAUCHE");
        gauche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gaucheActionPerformed(evt);
            }
        });
        jPanel1.add(gauche);

        droite.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        droite.setText("DROITE");
        droite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                droiteActionPerformed(evt);
            }
        });
        jPanel1.add(droite);

        matrice.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10"
            }
        ));
        jScrollPane1.setViewportView(matrice);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 792, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void hautActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hautActionPerformed
        IRebot rebot = (IRebot) Lookup.getInstance().getService(IRebot.class); 
        rebot.haut();
        
    }//GEN-LAST:event_hautActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         IRebot rebot = (IRebot) Lookup.getInstance().getService(IRebot.class); 
        rebot.bas();
         
    }//GEN-LAST:event_jButton2ActionPerformed

    private void gaucheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gaucheActionPerformed
         IRebot rebot =(IRebot) Lookup.getInstance().getService(IRebot.class); 
        rebot.gauche();
     
    }//GEN-LAST:event_gaucheActionPerformed

    private void droiteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_droiteActionPerformed
         IRebot rebot =(IRebot) Lookup.getInstance().getService(IRebot.class); 
        rebot.droite();
      
    }//GEN-LAST:event_droiteActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton droite;
    private javax.swing.JButton gauche;
    private javax.swing.JButton haut;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable matrice;
    // End of variables declaration//GEN-END:variables

 
    
    @Override
    public void propertyChange(PropertyChangeEvent pce) {
        IRebot rebott = (IRebot) Lookup.getInstance().getService(IRebot.class);
        List<Integer> list = rebott.getPosition();
        int xRebot = list.get(0);
        int yRebot = list.get(1);
        System.out.println(xRebot+"........"+yRebot+"\n");
    }
}
